import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CanActivate } from '@angular/router/src/utils/preactivation';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  path: ActivatedRouteSnapshot[];
  route: ActivatedRouteSnapshot;
  //router: any;

  constructor(private authService: AuthService, private router:Router){}   
  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    //return this.authService.islogin;
    if(this.authService.islogin){
      return true;
    }
    else{
      this.router.navigate(['']);
      return false;
    }
  }
  
}
