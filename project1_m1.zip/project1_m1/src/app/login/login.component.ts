import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public username: string;
  public password: string;
  public userData: any;
  public usernameFromJSON: any;
  public pwdFromJSON: any;

  constructor(private router: Router, private authService: AuthService) { }
  ngOnInit() {
    this.getData();
  }

  getData() {
    this.authService.getJSONData().subscribe(res => {
      this.userData = res;
    });
  }

  login() {
    // this.userData.forEach(element => {
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.userData.length; i++) {
      // console.log('element', this.userData[i]);
      // console.log('User name', this.username);
      // console.log('Pass', this.password);
      if (this.userData[i].username === this.username && this.userData[i].password === this.password) {
        this.authService.setLogin(true);
        this.router.navigate(['']);
        break;
      } else {
        alert('Invalid');
      }
    }
    // });
  }
}
