import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from 'src/app/productservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  images: any[];

  constructor() { 
  }

  ngOnInit() {
    this.images = [];
        this.images.push({source:'assets/offer-1.jpg', alt:'Get upto 40% discount on fastrack watches', title:'Fastrack offers'});
        this.images.push({source:'assets/offer-2.jpg', alt:'Flat 25% off', title:'Citizen and Guess offers'});
        this.images.push({source:'assets/offer-3.jpg', alt:'We have Precious Omega watches', title:'Omega watches'});
        this.images.push({source:'assets/offer-4.jpg', alt:'50% off', title:'Michell Hill watches'});
        this.images.push({source:'assets/offer-5.jpg', alt:'10% Discount', title:'Diesel Watches'});
   
  }
 
}
