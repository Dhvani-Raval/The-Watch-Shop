export interface list{
    id:string;
    product_name:string;
    Price:number;
    Brand: string;
    Qauntity :number;
    Image: ImageData;

}