import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../../productservice.service';
import { list } from './list';
import { CartService } from 'src/app/cart.service';
import { MessageService, SelectItem } from 'primeng/api';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  providers: [MessageService]
})
export class ProductListComponent implements OnInit {

  list1: list;
  public value: any;
  selectedWatch: list;
  displayDialog: boolean;
  cart1 = [];
  sortOptions: SelectItem[];
  sortKey: string;
  sortField: string;
  sortOrder: number;
  comment = false;
  comments = [];
  email: any;
  feedback1: any;
  public loginValue: boolean;

  constructor(private details: ProductserviceService, private cart: CartService,
              private messageService: MessageService, private router: Router,
              private authService: AuthService) { }

  ngOnInit() {
    this.showdetails();
    this.sortOptions = [
      { label: 'High to Low Price', value: '!Price' },
      { label: 'Low to High Price', value: 'Price' },
      { label: 'Brand', value: 'Brand' }
    ];
    this.loginValue = this.authService.getLogin();
  }

  showdetails() {
    this.details.getdetails().subscribe(
      (data: list) => {
        this.value = data;
      });
  }
  selectWatch(event: Event, list1: list) {
    this.selectedWatch = list1;
    this.displayDialog = true;
    event.preventDefault();
  }

  onSortChange(event) {
    const value = event.value;
    if (value.indexOf('!') === 0) {
      this.sortOrder = -1;
      this.sortField = value.substring(1, value.length);
    } else {
      this.sortOrder = 1;
      this.sortField = value;
    }
  }
  onDialogHide() {
    this.selectedWatch = null;
  }
  addtocart(list1: list) {
    this.selectedWatch = list1;
    this.messageService.add({ severity: 'success', summary: 'Success Message', detail: 'Product added into cart' });
    this.cart.setdata(this.selectedWatch);
    if (this.authService.getLoginCount() < 1) {
      this.router.navigate(['login']);
    }
  }

  feedback(email: any, feedback1: any, index: any) {
    this.comment = true;
    this.comments.push({ email: this.email, feedback: this.feedback1, id: index.id });
    this.email = '';
    this.feedback1 = '';
  }

}
