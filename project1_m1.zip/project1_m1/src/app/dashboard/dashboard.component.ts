import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
declare var jQuery: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public show: boolean;
  public showList: boolean;
  public showHome = true;
  public showabout = false;
  public showcheckout = true;
  public loginValue: boolean;
  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {
    // tslint:disable-next-line:only-arrow-functions
    jQuery(document).ready(function() {
      // tslint:disable-next-line:only-arrow-functions
      jQuery('#sidebarCollapse').on('click', function() {
        jQuery('#sidebar').toggleClass('active');
      });
    });
    this.loginValue = this.authService.getLogin();
  }
  onClicklist() {
    this.show = false;
    this.showList = true;
    this.router.navigate(['/product-list']);
  }
  onclickcart() {
    this.showList = false;
    this.showcheckout = false;
    this.show = true;
    this.router.navigate(['/shopping-cart']);
  }
  home() {
    this.show = false;
    this.showList = false;
    this.router.navigate(['/home']);
  }
  aboutus() {
    this.show = false;
    this.showList = false;
    this.router.navigate(['/about-us']);
  }
  Logout(){
    this.loginValue = false;
    // this.router.navigate(['']);
    console.log("Successfully logged out");
  }

}
