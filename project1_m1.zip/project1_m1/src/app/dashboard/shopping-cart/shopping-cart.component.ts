import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/cart.service';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
  providers: [MessageService]
})
export class ShoppingCartComponent implements OnInit {

  public getAddToCartData = [];
  public item;
  public removeItem;
  public totalPrice = 0;
  public totalProducts = 0;
  showcheckout = false;
  show = true;
  thankyou = true;
  constructor(private cart: CartService, private messageService: MessageService, private router: Router) { }

  ngOnInit() {
    this.getAddToCartData = this.cart.getdata();
    this.totalProducts = this.getAddToCartData.length;
    this.getAddToCartData.forEach(element => {
      this.totalPrice += element.Price;
    });
  }

  remove(item) {
    this.getAddToCartData.forEach((element, index) => {
      if (element.id === item.id) {
        this.messageService.add({ severity: 'success', summary: 'Success Message', detail: 'Product Removed Successfully' });
        this.getAddToCartData.splice(item, 1);
        // this.messageService.add({severity:'success', summary: 'Success Message', detail:'Product Removed Successfully'});
        this.totalPrice -= element.Price;
      }
    });
    this.totalProducts = this.getAddToCartData.length;
    // console.log('remaining', this.getAddToCartData);
  }
  checkout() {
    this.showcheckout = true;
    // this.getAddToCartData= null;
    // this.totalPrice =0;
    // this.totalProducts = 0;
    this.router.navigate(['/shopping-cart/checkout']);

  }
}
