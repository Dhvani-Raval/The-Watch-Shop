import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService 
{
  public islogin = false;
  public count = 0;
  constructor(private router: Router, private http: HttpClient) { }
  setLogin(value) 
  {
    this.islogin = value;
    this.count++;
  }

  getLogin() {
    return this.islogin;
  }

  getLoginCount() {
    return this.count;
  }
  getJSONData() {
    return this.http.get('./assets/details.json');
  }
}
