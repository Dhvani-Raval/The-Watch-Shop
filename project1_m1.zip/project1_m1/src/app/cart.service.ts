import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public addToCartData= [];

 // public tempobj = [];
 
  constructor() { }

  setdata(data) {
    this.addToCartData.push(data);
  }
  getdata() {
    return this.addToCartData;
  }
  clearCart() {
    this.addToCartData = [];
    return this.addToCartData;
  }
}
