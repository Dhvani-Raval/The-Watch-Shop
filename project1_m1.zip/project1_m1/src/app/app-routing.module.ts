import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { ErrorComponentComponent } from './error-component/error-component.component';
import { ProductListComponent } from './dashboard/product-list/product-list.component';
import { ShoppingCartComponent } from './dashboard/shopping-cart/shopping-cart.component';
import { HomeComponent } from './dashboard/home/home.component';
import { AboutUsComponent } from './dashboard/about-us/about-us.component';
import { CheckoutComponent } from './dashboard/shopping-cart/checkout/checkout.component';
import { ThankYouComponent } from './dashboard/shopping-cart/checkout/thank-you/thank-you.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      {
        path: 'home',
        component: HomeComponent,
      },
      {
        path: 'about-us',
        component: AboutUsComponent
      },
      {
        path: 'product-list',
        component: ProductListComponent,
      },
      {
        path: 'shopping-cart',
        component: ShoppingCartComponent,
        canActivate:[AuthGuard],
        children: [
      {
        path: 'checkout',
        component: CheckoutComponent,
        children:[
          {
          path: 'order-successful',
          component: ThankYouComponent
          }
        ]
      }
    ]
   
  }
]
  },
  {
    path: 'login',
    component: LoginComponent,
    //canActivate:[AuthGuard]
  },
  // {
  //   path: '',
  //   redirectTo: '/login',
  //   pathMatch: 'full'
  // },
  // {
  //   path: 'dashboard',
  //   component: DashboardComponent,
  // canActivate:[AuthGuard],
  // children: [
  //   {
  //     path: 'home',
  //     component: HomeComponent,
  //   },
  //   {
  //     path: 'about-us',
  //     component: AboutUsComponent
  //   },
  //   {
  //     path: 'product-list',
  //     component: ProductListComponent,
  //   },
  //   {
  //     path: 'shopping-cart',
  //     component: ShoppingCartComponent,
  //     children: [
  //       {
  //         path: 'checkout',
  //         component: CheckoutComponent,
  //         children: [
  //           {
  //             path: 'order-successful',
  //             component: ThankYouComponent
  //           }
  //         ]
  //       }
  //     ]
  //   }
  // ]
  // },
  { path: '**', component: ErrorComponentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
