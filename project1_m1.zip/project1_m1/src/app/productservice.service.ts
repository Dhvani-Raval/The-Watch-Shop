import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  URL='../assets/product-list.json';

  constructor(private http:HttpClient) { }
  getdetails()
  {
    return this.http.get(this.URL);
  }
}
