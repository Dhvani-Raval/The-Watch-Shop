import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { ErrorComponentComponent } from './error-component/error-component.component';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { HttpClientModule } from '@angular/common/http';
import { ProductListComponent } from './dashboard/product-list/product-list.component';
import { DataViewModule } from 'primeng/dataview';
import { PanelModule } from 'primeng/panel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DialogModule } from 'primeng/dialog';
import { ShoppingCartComponent } from './dashboard/shopping-cart/shopping-cart.component';
import { ToastModule } from 'primeng/toast';
import { HomeComponent } from './dashboard/home/home.component';
import { GalleriaModule } from 'primeng/galleria';
import { AboutUsComponent } from './dashboard/about-us/about-us.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { DropdownModule } from 'primeng/dropdown';
import { CheckoutComponent } from './dashboard/shopping-cart/checkout/checkout.component';
import { ThankYouComponent } from './dashboard/shopping-cart/checkout/thank-you/thank-you.component';
import { RatingModule } from 'primeng/rating';
import { InputTextareaModule } from 'primeng/inputtextarea';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    ErrorComponentComponent,
    ProductListComponent,
    ShoppingCartComponent,
    HomeComponent,
    AboutUsComponent,
    CheckoutComponent,
    ThankYouComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    InputTextModule,
    PasswordModule,
    ButtonModule,
    NgbModule,
    MDBBootstrapModule,
    HttpClientModule,
    DataViewModule,
    PanelModule,
    BrowserAnimationsModule,
    DialogModule,
    CommonModule,
    ToastModule,
    GalleriaModule,
    AngularFontAwesomeModule,
    DropdownModule,
    RatingModule,
    InputTextareaModule
  ],
  exports: [
    InputTextModule,
    PasswordModule,
    ButtonModule, DialogModule, CommonModule
  ],
  providers: [AuthService, AuthGuard],
  bootstrap: [AppComponent]

})
export class AppModule { }
